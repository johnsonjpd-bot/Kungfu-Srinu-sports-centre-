KSSC website update
- Coach 2 uses the newly supplied white-shirt photo.
- Coach 4 (M. Bobby) uses the previously supplied red T-shirt photo.
- Other website sections are retained.
Open index.html to preview. Upload the file to your hosting to publish.
